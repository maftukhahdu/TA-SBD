<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>LOGIN ADMIN</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/best-carousel-slide.css">
    <link rel="stylesheet" href="assets/css/Carousel-Hero.css">
    <link rel="stylesheet" href="assets/css/Header-Blue.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/News-Cards.css">
</head>

<body class="bg-gradient-primary" style="background-color: rgb(255,255,255);filter: hue-rotate(0deg) saturate(104%);">
    <div class="container" style="margin-top: 79px;">
        <div class="card shadow-lg o-hidden border-0 my-5">
            <div class="card-body p-0" style="height: 428px;">
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-flex">
                        <div class="flex-grow-1 bg-register-image" style="background-image: url(&quot;assets/img/tmp749693330782158850.jpg&quot;);height: 430px;"></div>
                    </div>
                    <div class="col-lg-7">
                        <div class="p-5" style="height: 430px;">
                            <div class="text-center">
                                <h4 class="text-dark mb-4">Masuk untuk Admin</h4>
                            </div>
                            <form class="user" action="proseslogin.php" method="post" style="height: 200px;">
                                <div class="form-group"><input class="form-control form-control-user" type="email" placeholder="Username" name="username"></div>
                                <div class="form-group"><input class="form-control form-control-user" type="password" placeholder="Password" name="password"><button class="btn btn-primary btn-block text-white btn-user" type="submit" style="margin-top: 14px;">Masuk</button></div>
                                <hr>
                            </form>
                            <div class="text-center"><a class="small" href="index.php">Kembali ke Home</a></div>
                            <div class="text-center"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>