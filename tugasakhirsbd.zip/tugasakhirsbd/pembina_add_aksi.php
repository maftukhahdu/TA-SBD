<?php
include "koneksi.php";
$nama_pembina2    = $_POST['nama_pembina2'];
$nip_pembina   = $_POST['nip_pembina'];
$kontak_pembina   = $_POST['kontak_pembina'];
$query  = mysqli_query($connect, "insert into pembina(nama_pembina,nip_pembina,kontak_pembina)
values ('$nama_pembina2','$nip_pembina','$kontak_pembina')");
if ($query) {
    header('location:pembina_admin.php');
} else {
    echo mysqli_error($connect);
}
