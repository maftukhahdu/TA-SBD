<?php
include "koneksi.php";
$nama    = $_POST['nama'];
$nim   = $_POST['nim'];
$jurusan   = $_POST['jurusan'];
$angkatan   = $_POST['angkatan'];
$kontak   = $_POST['kontak'];
$nama_ukm   = $_POST['nama_ukm'];

$query  = mysqli_query($connect, "update anggota set nama='$nama',nim='$nim',jurusan='$jurusan',angkatan='$angkatan',nama_ukm='$nama_ukm' where nim='$nim' ")
or die(mysqli_error($connect));
if ($query) {
    header('location:anggota_admin.php');
} else {
    echo mysqli_error($connect);
}
?>