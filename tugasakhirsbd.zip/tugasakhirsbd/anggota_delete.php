<?php
include "koneksi.php";
$id = $_GET['id'];
$query = mysqli_query($connect, "delete from anggota where nim='$id'")
    or die(mysqli_error($connect));
if ($query) {
    header('location:anggota_admin.php');
} else {
    echo mysqli_error($connect);
}
