<?php
include "koneksi.php";
$kode_jadwal    = $_POST['kode_jadwal'];
$hari_latihan    = $_POST['hari_latihan'];
$tempat_latihan   = $_POST['tempat_latihan'];

$query  = mysqli_query($connect, "update jadwal set hari_latihan='$hari_latihan',tempat_latihan='$tempat_latihan' where kode_jadwal='$kode_jadwal' ")
or die(mysqli_error($connect));
if ($query) {
    header('location:jadwal_admin.php');
} else {
    echo mysqli_error($connect);
}
?>