<?php
include "koneksi.php";
$hari_latihan    = $_POST['hari_latihan'];
$tempat_latihan   = $_POST['tempat_latihan'];
$query  = mysqli_query($connect, "insert into jadwal (hari_latihan,tempat_latihan)
values ('$hari_latihan','$tempat_latihan')");
if ($query) {
    header('location:jadwal_admin.php');
} else {
    echo mysqli_error($connect);
}
