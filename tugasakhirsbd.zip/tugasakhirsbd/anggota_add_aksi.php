<?php
include "koneksi.php";
$nama    = $_POST['nama'];
$nim   = $_POST['nim'];
$jurusan   = $_POST['jurusan'];
$angkatan   = $_POST['angkatan'];
$kontak   = $_POST['kontak'];
$nama_ukm   = $_POST['nama_ukm'];

$query  = mysqli_query($connect, "INSERT INTO anggota (`nama`, `nim`, `jurusan`, `angkatan`, `kontak`, `nama_ukm`) VALUES ('$nama', '$nim', '$jurusan', '$angkatan', '$kontak', '$nama_ukm')");
if ($query) {
    header('location:anggota_admin.php');
} else {
    echo mysqli_error($connect);
} 
?>