<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>TA</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/best-carousel-slide.css">
    <link rel="stylesheet" href="assets/css/Carousel-Hero.css">
    <link rel="stylesheet" href="assets/css/Header-Blue.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
</head>

<body>
    <div>
        <div class="header-blue" style="background-image: url(&quot;assets/img/Beautiful-Adidas-Wallpaper.png&quot;);background-color: rgb(255,255,255);">
            <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
                <div class="container-fluid"><button class="navbar-toggler" data-toggle="collapse"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button></div>
            </nav>
            <div class="container hero" style="margin-top: 0px;">
                <div class="row">
                    <div class="col-12 col-lg-6 col-xl-5 offset-xl-1">
                        <h1>Sistem Informasi UKM</h1>
                        <p>Selamat Datang di Sistem Informasi UKM Fakultas Teknik. Disini anda dapat melihat informasi mengenai kegiatan UKM yang ada di Fakultas Teknik<br></p><a class="card-link" href="home_ang.php"><button class="btn btn-danger btn-lg swing animated action-button" type="submit"
                            style="background-color: rgb(255,255,255);color: rgb(0,0,0);width: 110px;">Anggota</button></a><a class="card-link" href="login_admin.php"><button class="btn btn-light btn-lg action-button" data-bs-hover-animate="jello" type="button" style="margin-left: 15px;width: 110px;">Admin</button></a></div>
                    <div
                        class="col-md-5 col-lg-5 offset-lg-1 offset-xl-0 d-none d-lg-block phone-holder">
                        <div class="iphone-mockup"><img class="pulse animated device" src="assets/img/iphone.svg">
                            <div data-bs-hover-animate="tada" class="screen" style="background-image: url(&quot;assets/img/0JFtB8.jpg&quot;);"></div>
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>