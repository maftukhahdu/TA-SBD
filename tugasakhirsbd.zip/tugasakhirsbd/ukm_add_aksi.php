<?php
include "koneksi.php";
$nama_ukm2    = $_POST['nama_ukm2'];
$kode_pembina   = $_POST['kode_pembina'];
$kode_jadwal   = $_POST['kode_jadwal'];

$query  = mysqli_query($connect, "INSERT INTO ukm (`nama_ukm`, `kode_pembina`, `kode_jadwal`) VALUES ('$nama_ukm2', '$kode_pembina', '$kode_jadwal')");
if ($query) {
    header('location:ukm_admin.php');
} else {
    echo mysqli_error($connect);
}
?>