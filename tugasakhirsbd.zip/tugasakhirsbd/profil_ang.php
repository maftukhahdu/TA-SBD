<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Profile - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/best-carousel-slide.css">
    <link rel="stylesheet" href="assets/css/Carousel-Hero.css">
    <link rel="stylesheet" href="assets/css/Header-Blue.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/News-Cards.css">
</head>

<body id="page-top">
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"><i class="fas fa-basketball-ball"></i></div>
                    <div class="sidebar-brand-text mx-3"><span>si ukm</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" href="home_ang.php"><i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                        <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                        </a>
                        <a class="nav-link" href="anggota.php"><i class="fas fa-user-friends"></i>
                            <span>Anggota</span>
                        </a>
                        </a>
                        <a class="nav-link" href="pembina.php"><i class="fas fa-handshake">></i>
                            <span>Pembina</span>
                        </a>
                        <a class="nav-link" href="ukm.php"><i class="fas fa-volleyball-ball"></i>
                            <span>UKM</span>
                        </a>
                        <a class="nav-link" href="jadwal.php"><i class="fas fa-clock"></i>
                            <span>Jadwal</span>
                        </a>
                    </li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid">
                            </div>
                        </form><a href="index.php">Keluar</a></div>
                </nav>
                <div class="container-fluid">
                    <h3 class="text-dark mb-4">Profil UKM</h3>
                    <div class="row mb-3">
                        <div class="col-lg-8">
                            <div class="row" style="width: 911px;">
                                <div class="col">
                                    <div class="card shadow mb-3" style="height: 500px;margin-top: 16px;">
                                        <div class="card-header py-3">
                                            <div class="row" style="width: 800px;">
                                                <div class="col" style="width: 554px;">
                                                    <p class="text-primary m-0 font-weight-bold" style="width: 641px;font-size: 22;">Profil</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                        <?php //isikan dengan query select data
                                        include "koneksi.php";
                                        $id = $_GET['id'];
                                        $query = mysqli_query($connect, "select * from ukm where kode_ukm='$id'") or die(mysqli_error($connect));

                                        while ($plg = mysqli_fetch_array($query)) {
                                            $kode_ukm = $plg['kode_ukm'];
                                            $nama_ukm = $plg['nama_ukm'];
                                            $kode_pembina = $plg['kode_pembina'];
                                            $kode_jadwal = $plg['kode_jadwal'];
                                        }
                                        ?>
                                         <form method='POST' action='aksi_edit_alat.php?id_alat=<?php echo    $id;    ?>'>
                                            <div class="form-group">
                                                <label>
                                                    <strong>Kode UKM</strong>
                                                    <br>
                                                </label>
                                                <input disabled value="<?php echo $kode_ukm; ?>" class="form-control" type="number" name="kode_ukm">
                                            </div>
                                            <div class="form-group">
                                                <label>
                                                    <strong>Nama UKM</strong>
                                                    <br>
                                                </label>
                                                <input disabled value="<?php echo $nama_ukm; ?>" class="form-control" type="text" name="nama_ukm">
                                            </div>
                                            <div class="form-group">
                                            <label>
                                                <strong>Kode Pembina</strong>
                                                <br>
                                            </label>
                                            <input disabled value="<?php echo $kode_pembina; ?>" class="form-control" type="number" name="kode_pembina">
                                            </div>
                                            <div class="form-group">
                                            <label>
                                                <strong>Kode Jadwal</strong>
                                                <br>
                                            </label>
                                            <input disabled value="<?php echo $kode_jadwal; ?>" class="form-control" type="number" name="kode_jadwal">
                                            </div>
                                            <div class="form-group">
                                            <label>
                                                <strong>Anggota</strong>
                                                <br>
                                            </label>
                                            <div>
                                                <a href="aksi_ang_profil.php" style="margin-left: 0px;">Lihat Angota</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <div class="card shadow" style="height: 350px;margin-top: 10px;">
                                        <div class="card-header py-3">
                                            <div class="row" style="width: 800px;">
                                                <div class="col" style="width: 554px;">
                                                    <p class="text-primary m-0 font-weight-bold" style="width: 641px;font-size: 22;">Pembina</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                        <?php //isikan dengan query select data
                                        include "koneksi.php";
                                        $id = $_GET['id'];
                                        $query = mysqli_query($connect, "select * from pembina where kode_pembina='$id'") or die(mysqli_error($connect));

                                        while ($plg = mysqli_fetch_array($query)) {
                                            $nama_pembina = $plg['nama_pembina'];
                                            $nip_pembina = $plg['nip_pembina'];
                                            $kontak_pembina = $plg['kontak_pembina'];
                                        }
                                        ?>
                                         <form method='POST' action='aksi_edit_alat.php?id_alat=<?php echo    $id;    ?>'>
                                            <div class="form-group">
                                                <label>
                                                    <strong>Nama</strong>
                                                    <br>
                                                </label>
                                                <input disabled value="<?php echo $nama_pembina; ?>" class="form-control" type="text" name="nama_pembina">
                                            </div>
                                            <div class="form-group">
                                                <label>
                                                    <strong>NIP</strong>
                                                    <br>
                                                </label>
                                                <input disabled value="<?php echo $nip_pembina; ?>" class="form-control" type="number" name="nip_pembina">
                                            </div>
                                            <div class="form-group">
                                            <label>
                                                <strong>Kontak</strong>
                                                <br>
                                            </label>
                                            <input disabled value="<?php echo $kontak_pembina; ?>" class="form-control" type="number" name="kontak_pembina">
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <div class="card shadow" style="height: 350px;margin-top: 10px;">
                                        <div class="card-header py-3">
                                            <div class="row" style="width: 800px;">
                                                <div class="col" style="width: 554px;">
                                                    <p class="text-primary m-0 font-weight-bold" style="width: 641px;font-size: 22;">Jadwal Latihan</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                        <?php //isikan dengan query select data
                                        include "koneksi.php";
                                        $id = $_GET['id'];
                                        $query = mysqli_query($connect, "select * from Jadwal where kode_jadwal='$id'") or die(mysqli_error($connect));

                                        while ($plg = mysqli_fetch_array($query)) {
                                            $kode_jadwal = $plg['kode_jadwal'];
                                            $hari_latihan = $plg['hari_latihan'];
                                            $tempat_latihan = $plg['tempat_latihan'];
                                        }
                                        ?>
                                         <form method='POST' action='aksi_edit_alat.php?id_alat=<?php echo    $id;    ?>'>
                                            <div class="form-group">
                                                <label>
                                                    <strong>Kode</strong>
                                                    <br>
                                                </label>
                                                <input disabled value="<?php echo $kode_jadwal; ?>" class="form-control" type="number" name="kode_jadwal">
                                            </div>
                                            <div class="form-group">
                                                <label>
                                                    <strong>Hari</strong>
                                                    <br>
                                                </label>
                                                <input disabled value="<?php echo $hari_latihan; ?>" class="form-control" type="text" name="hari_latihan">
                                            </div>
                                            <div class="form-group">
                                            <label>
                                                <strong>Tempat</strong>
                                                <br>
                                            </label>
                                            <input disabled value="<?php echo $tempat_latihan; ?>" class="form-control" type="text" name="tempat_latihan">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Maftukhah Dwi Utami</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>