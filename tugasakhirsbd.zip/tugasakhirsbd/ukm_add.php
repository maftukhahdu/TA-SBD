<?php
session_start();
include 'koneksi.php';
if ( $_SESSION['username']) {
    ;
  
}else {
  echo "Login Gagal:(";
       header("location:login_admin.php");}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Anggota</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/best-carousel-slide.css">
    <link rel="stylesheet" href="assets/css/Carousel-Hero.css">
    <link rel="stylesheet" href="assets/css/Header-Blue.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/News-Cards.css">
</head>

<body id="page-top">
    <div id="wrapper">
        <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"><i class="fas fa-basketball-ball"></i></div>
                    <div class="sidebar-brand-text mx-3"><span>si ukm</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" href="home_admin.php"><i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                        <a class="nav-link" href="dashboard_admin.php"><i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                        </a>
                        <a class="nav-link" href="anggota_admin.php"><i class="fas fa-user-friends"></i>
                            <span>Anggota</span>
                        </a>
                        </a>
                        <a class="nav-link" href="pembina_admin.php"><i class="fas fa-handshake">></i>
                            <span>Pembina</span>
                        </a>
                        <a class="nav-link" href="ukm_admin.php"><i class="fas fa-volleyball-ball"></i>
                            <span>UKM</span>
                        </a>
                        <a class="nav-link" href="jadwal_admin.php"><i class="fas fa-clock"></i>
                            <span>Jadwal</span>
                        </a>
                    </li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                    <div class="container-fluid">
                            </div>
                        </form><a href="index.php">Keluar</a></div>
                </nav>
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-dark mb-0">UKM</h3></div>
                    <div class="card shadow">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 font-weight-bold">Daftar UKM</p>
                        </div>
                        <div class="card-body">
                                <form method="post" action="ukm_add_aksi.php">
                                    <div class="form-group">
                                        <label>
                                            <strong>Nama</strong>
                                            <br>
                                        </label>
                                        <input class="form-control" type="text" name="nama_ukm2">
                                    </div>
                                    <div class="form-group">
                                    <label for="address">
                                        <strong>Kode Pembina</strong>
                                    </label>
                                    <select class="form-control" name='kode_pembina'>
                                        <?php include "koneksi.php";
                                        $query = "SELECT * FROM pembina";
                                        $result    = mysqli_query($connect, $query) or die(mysqli_error($connect));
                                        while ($row    = mysqli_fetch_array($result)) { ?>
                                            <option value="<?php echo    $row['kode_pembina'];    ?>"><?php echo $row['kode_pembina']; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="address">
                                            <strong>Kode Jadwal</strong>
                                        </label>
                                        <select class="form-control" name='kode_jadwal'>
                                            <?php include "koneksi.php";
                                            $query = "SELECT * FROM jadwal";
                                            $result    = mysqli_query($connect, $query) or die(mysqli_error($connect));
                                            while ($row    = mysqli_fetch_array($result)) { ?>
                                                <option value="<?php echo    $row['kode_jadwal'];    ?>"><?php echo $row['kode_jadwal']; ?></option>
                                                <?php } ?>
                                            </select></div>
                                            <div class="form-group"><button class="btn btn-success btn-sm" type="submit">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <footer class="bg-white sticky-footer">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Maftukhah Dwi Utami</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>